// src/database.js
const sqlite3 = require('sqlite3').verbose();
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const path = require('path');

let db = null;

async function getDatabase() {
  return new Promise((resolve, reject) => {
    if (db) {
      resolve(db);
      return;
    }

    // در Netlify از /tmp استفاده می‌کنیم
    const dbPath = path.join('/tmp', 'exchange_platform.db');
    db = new sqlite3.Database(dbPath, async (err) => {
      if (err) {
        reject(err);
      } else {
        await initializeTables();
        await seedDatabase();
        resolve(db);
      }
    });
  });
}

function initializeTables() {
  return new Promise((resolve, reject) => {
    db.serialize(() => {
      // کپی کردن تمام جداول از server-sqlite.js
      db.run(`
        CREATE TABLE IF NOT EXISTS tenants (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          tenant_id VARCHAR(50) UNIQUE NOT NULL,
          name VARCHAR(255) NOT NULL,
          subdomain VARCHAR(100) UNIQUE,
          plan VARCHAR(50) NOT NULL DEFAULT 'basic',
          status VARCHAR(20) NOT NULL DEFAULT 'pending',
          admin_email VARCHAR(255) NOT NULL,
          admin_phone VARCHAR(20),
          exchange_address TEXT,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          approved_at DATETIME,
          expires_at DATETIME,
          settings TEXT
        )
      `);

      db.run(`
        CREATE TABLE IF NOT EXISTS platform_users (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          email VARCHAR(255) UNIQUE NOT NULL,
          password_hash VARCHAR(255) NOT NULL,
          role VARCHAR(50) NOT NULL DEFAULT 'super_admin',
          tenant_id VARCHAR(50),
          name VARCHAR(255) NOT NULL,
          phone VARCHAR(20),
          status VARCHAR(20) NOT NULL DEFAULT 'active',
          last_login DATETIME,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          settings TEXT,
          FOREIGN KEY (tenant_id) REFERENCES tenants(tenant_id) ON DELETE CASCADE
        )
      `);

      db.run(`
        CREATE TABLE IF NOT EXISTS tenant_users (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          tenant_id VARCHAR(50) NOT NULL,
          email VARCHAR(255) NOT NULL,
          password_hash VARCHAR(255) NOT NULL,
          name VARCHAR(255) NOT NULL,
          role VARCHAR(50) NOT NULL DEFAULT 'customer',
          phone VARCHAR(20),
          status VARCHAR(20) NOT NULL DEFAULT 'active',
          p2p_enabled BOOLEAN DEFAULT 0,
          kyc_status VARCHAR(20) DEFAULT 'pending',
          balance DECIMAL(15,2) DEFAULT 0.00,
          last_login DATETIME,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          settings TEXT,
          UNIQUE(tenant_id, email)
        )
      `);

      db.run(`
        CREATE TABLE IF NOT EXISTS tenant_transactions (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          tenant_id VARCHAR(50) NOT NULL,
          user_id INTEGER,
          type VARCHAR(50) NOT NULL,
          amount DECIMAL(15,2) NOT NULL,
          currency VARCHAR(10) NOT NULL DEFAULT 'USD',
          status VARCHAR(20) NOT NULL DEFAULT 'pending',
          description TEXT,
          reference_id VARCHAR(100),
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          completed_at DATETIME,
          FOREIGN KEY (user_id) REFERENCES tenant_users(id) ON DELETE CASCADE
        )
      `);

      resolve();
    });
  });
}

async function seedDatabase() {
  return new Promise(async (resolve, reject) => {
    try {
      // چک کنیم اگر داده وجود دارد
      db.get('SELECT COUNT(*) as count FROM platform_users', async (err, row) => {
        if (err) {
          reject(err);
          return;
        }

        if (row.count > 0) {
          resolve(); // اگر داده دارد، seed نکن
          return;
        }

        // کپی کردن seed از server-sqlite.js
        console.log('🌱 Seeding database...');

        // Super Admin
        const superAdminPassword = await bcrypt.hash('SuperAdmin@2024!', 10);
        db.run(`
          INSERT INTO platform_users (email, password_hash, role, name, phone)
          VALUES (?, ?, 'super_admin', 'مدیر کل سیستم', '+98 21 1234 5678')
        `, ['super@admin.com', superAdminPassword]);

        // Sample tenants
        const tenants = [
          {
            tenant_id: 'ARIA_001',
            name: 'صرافی آریا',
            subdomain: 'aria',
            plan: 'professional',
            status: 'active',
            admin_email: 'admin@aria.com'
          },
          {
            tenant_id: 'TALAEI_002',
            name: 'صرافی طلایی',
            subdomain: 'talaei',
            plan: 'basic',
            status: 'active',
            admin_email: 'admin@talaei.com'
          }
        ];

        for (const tenant of tenants) {
          db.run(`
            INSERT INTO tenants (tenant_id, name, subdomain, plan, status, admin_email, approved_at, expires_at)
            VALUES (?, ?, ?, ?, ?, ?, datetime('now'), datetime('now', '+1 year'))
          `, [tenant.tenant_id, tenant.name, tenant.subdomain, tenant.plan, tenant.status, tenant.admin_email]);

          const adminPassword = await bcrypt.hash('Admin@123', 10);
          db.run(`
            INSERT INTO platform_users (email, password_hash, role, tenant_id, name)
            VALUES (?, ?, 'tenant_admin', ?, ?)
          `, [tenant.admin_email, adminPassword, tenant.tenant_id, `مدیر ${tenant.name}`]);
        }

        console.log('✅ Database seeded successfully');
        resolve();
      });
    } catch (error) {
      reject(error);
    }
  });
}

function authenticateToken(token) {
  return new Promise((resolve, reject) => {
    jwt.verify(token, process.env.JWT_SECRET || 'ExchangePlatform2024SecretKey', (err, user) => {
      if (err) resolve(null);
      else resolve(user);
    });
  });
}

module.exports = { getDatabase, authenticateToken };
// به src/database.js اضافه کنید:

// در تابع initializeTables():
db.run(`
  CREATE TABLE IF NOT EXISTS accounting_entries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tenant_id VARCHAR(50) NOT NULL,
    entry_type VARCHAR(20) NOT NULL, -- 'income', 'expense', 'commission'
    amount DECIMAL(15,2) NOT NULL,
    description TEXT,
    category VARCHAR(50),
    reference_transaction_id INTEGER,
    created_by INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (reference_transaction_id) REFERENCES tenant_transactions(id)
  )
`);

db.run(`
  CREATE TABLE IF NOT EXISTS commission_rates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tenant_id VARCHAR(50) NOT NULL,
    transaction_type VARCHAR(20) NOT NULL, -- 'buy', 'sell', 'p2p'
    rate DECIMAL(5,4) NOT NULL, -- 0.0150 = 1.5%
    min_amount DECIMAL(15,2) DEFAULT 0,
    max_amount DECIMAL(15,2),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )
`);

db.run(`
  CREATE TABLE IF NOT EXISTS partners (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tenant_id VARCHAR(50) NOT NULL,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255),
    share_percentage DECIMAL(5,2) NOT NULL, -- 25.50 = 25.5%
    investment_amount DECIMAL(15,2) DEFAULT 0,
    status VARCHAR(20) DEFAULT 'active',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )
`);

db.run(`
  CREATE TABLE IF NOT EXISTS exchange_rates (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tenant_id VARCHAR(50) NOT NULL,
    currency_from VARCHAR(10) NOT NULL,
    currency_to VARCHAR(10) NOT NULL,
    buy_rate DECIMAL(10,4) NOT NULL,
    sell_rate DECIMAL(10,4) NOT NULL,
    markup_percentage DECIMAL(5,2) DEFAULT 0,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )
`);
// src/database.js - در انتهای تابع initializeTables() اضافه کنید:

function initializeTables() {
  return new Promise((resolve, reject) => {
    db.serialize(() => {
      // جداول قبلی که دارید...
      // (tenants, platform_users, tenant_users, tenant_transactions)

      // 🆕 جداول جدید حسابداری:
      db.run(`
        CREATE TABLE IF NOT EXISTS accounting_entries (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          tenant_id VARCHAR(50) NOT NULL,
          entry_type VARCHAR(20) NOT NULL, -- 'income', 'expense', 'commission'
          amount DECIMAL(15,2) NOT NULL,
          description TEXT,
          category VARCHAR(50),
          reference_transaction_id INTEGER,
          created_by INTEGER,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (reference_transaction_id) REFERENCES tenant_transactions(id)
        )
      `);

      db.run(`
        CREATE TABLE IF NOT EXISTS commission_rates (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          tenant_id VARCHAR(50) NOT NULL,
          transaction_type VARCHAR(20) NOT NULL, -- 'buy', 'sell', 'p2p'
          rate DECIMAL(5,4) NOT NULL, -- 0.0150 = 1.5%
          min_amount DECIMAL(15,2) DEFAULT 0,
          max_amount DECIMAL(15,2),
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
      `);

      db.run(`
        CREATE TABLE IF NOT EXISTS partners (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          tenant_id VARCHAR(50) NOT NULL,
          name VARCHAR(255) NOT NULL,
          email VARCHAR(255),
          share_percentage DECIMAL(5,2) NOT NULL, -- 25.50 = 25.5%
          investment_amount DECIMAL(15,2) DEFAULT 0,
          status VARCHAR(20) DEFAULT 'active',
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
      `);

      db.run(`
        CREATE TABLE IF NOT EXISTS exchange_rates (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          tenant_id VARCHAR(50) NOT NULL,
          currency_from VARCHAR(10) NOT NULL,
          currency_to VARCHAR(10) NOT NULL,
          buy_rate DECIMAL(10,4) NOT NULL,
          sell_rate DECIMAL(10,4) NOT NULL,
          markup_percentage DECIMAL(5,2) DEFAULT 0,
          updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
      `);

      console.log('✅ Accounting tables created');
      resolve();
    });
  });
}