// netlify/functions/rates.js  
const { getDatabase, authenticateToken } = require('../../src/database');

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization', 
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    const authHeader = event.headers.authorization;
    const token = authHeader && authHeader.split(' ')[1];
    
    if (!token) {
      return {
        statusCode: 401,
        headers,
        body: JSON.stringify({ error: 'Access token required' })
      };
    }

    const user = await authenticateToken(token);
    if (!user) {
      return {
        statusCode: 403,
        headers,
        body: JSON.stringify({ error: 'Invalid token' })
      };
    }

    const db = await getDatabase();
    const { tenant_id } = event.queryStringParameters || {};
    const targetTenantId = tenant_id || user.tenantId;

    if (event.httpMethod === 'GET') {
      // دریافت نرخ‌های ارز
      const rates = await new Promise((resolve, reject) => {
        db.all('SELECT * FROM exchange_rates WHERE tenant_id = ? ORDER BY updated_at DESC', [targetTenantId], (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        });
      });

      // دریافت نرخ‌های کارمزد
      const commissionRates = await new Promise((resolve, reject) => {
        db.all('SELECT * FROM commission_rates WHERE tenant_id = ? ORDER BY created_at DESC', [targetTenantId], (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        });
      });

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ 
          success: true, 
          data: { 
            exchange_rates: rates,
            commission_rates: commissionRates
          }
        })
      };

    } else if (event.httpMethod === 'POST') {
      const { type, ...data } = JSON.parse(event.body);

      if (type === 'exchange_rate') {
        // تنظیم نرخ ارز
        const { currency_from, currency_to, buy_rate, sell_rate, markup_percentage } = data;
        
        await new Promise((resolve, reject) => {
          db.run(`
            INSERT OR REPLACE INTO exchange_rates (tenant_id, currency_from, currency_to, buy_rate, sell_rate, markup_percentage, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, datetime('now'))
          `, [targetTenantId, currency_from, currency_to, buy_rate, sell_rate, markup_percentage], (err) => {
            if (err) reject(err);
            else resolve();
          });
        });

        return {
          statusCode: 201,
          headers,
          body: JSON.stringify({ success: true, message: 'Exchange rate updated' })
        };

      } else if (type === 'commission_rate') {
        // تنظیم نرخ کارمزد
        const { transaction_type, rate, min_amount, max_amount } = data;
        
        await new Promise((resolve, reject) => {
          db.run(`
            INSERT OR REPLACE INTO commission_rates (tenant_id, transaction_type, rate, min_amount, max_amount)
            VALUES (?, ?, ?, ?, ?)
          `, [targetTenantId, transaction_type, rate, min_amount, max_amount], (err) => {
            if (err) reject(err);
            else resolve();
          });
        });

        return {
          statusCode: 201,
          headers,
          body: JSON.stringify({ success: true, message: 'Commission rate updated' })
        };
      }
    }

  } catch (error) {
    console.error('Rates error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: 'Server error', details: error.message })
    };
  }
};