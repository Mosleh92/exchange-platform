// netlify/functions/tenants.js
const { getDatabase, authenticateToken } = require('../../src/database');

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    // Extract JWT token
    const authHeader = event.headers.authorization;
    const token = authHeader && authHeader.split(' ')[1];
    
    if (!token) {
      return {
        statusCode: 401,
        headers,
        body: JSON.stringify({ error: 'Access token required' })
      };
    }

    const user = await authenticateToken(token);
    if (!user) {
      return {
        statusCode: 403,
        headers,
        body: JSON.stringify({ error: 'Invalid token' })
      };
    }

    const db = await getDatabase();

    if (event.httpMethod === 'GET') {
      const { id } = event.queryStringParameters || {};
      
      if (id) {
        // Get single tenant
        if (user.role !== 'super_admin' && user.tenantId !== id) {
          return {
            statusCode: 403,
            headers,
            body: JSON.stringify({ error: 'Access denied' })
          };
        }

        const tenant = await new Promise((resolve, reject) => {
          db.get('SELECT * FROM tenants WHERE tenant_id = ?', [id], (err, row) => {
            if (err) reject(err);
            else resolve(row);
          });
        });

        if (!tenant) {
          return {
            statusCode: 404,
            headers,
            body: JSON.stringify({ error: 'Tenant not found' })
          };
        }

        // Get stats
        const stats = await new Promise((resolve, reject) => {
          db.get(`
            SELECT 
              COUNT(DISTINCT tu.id) as user_count,
              COUNT(DISTINCT tt.id) as transaction_count,
              COALESCE(SUM(tt.amount), 0) as total_volume
            FROM tenants t
            LEFT JOIN tenant_users tu ON t.tenant_id = tu.tenant_id
            LEFT JOIN tenant_transactions tt ON t.tenant_id = tt.tenant_id
            WHERE t.tenant_id = ?
          `, [id], (err, row) => {
            if (err) reject(err);
            else resolve(row);
          });
        });

        return {
          statusCode: 200,
          headers,
          body: JSON.stringify({
            success: true,
            data: {
              ...tenant,
              stats: {
                users: stats.user_count || 0,
                transactions: stats.transaction_count || 0,
                volume: stats.total_volume || 0,
                p2p: 0
              }
            }
          })
        };

      } else {
        // Get all tenants (Super Admin only)
        if (user.role !== 'super_admin') {
          return {
            statusCode: 403,
            headers,
            body: JSON.stringify({ error: 'Access denied' })
          };
        }

        const tenants = await new Promise((resolve, reject) => {
          db.all(`
            SELECT t.*, 
                   COUNT(DISTINCT tu.id) as user_count,
                   COUNT(DISTINCT tt.id) as transaction_count,
                   COALESCE(SUM(tt.amount), 0) as total_volume
            FROM tenants t
            LEFT JOIN tenant_users tu ON t.tenant_id = tu.tenant_id
            LEFT JOIN tenant_transactions tt ON t.tenant_id = tt.tenant_id
            GROUP BY t.id
            ORDER BY t.created_at DESC
          `, (err, rows) => {
            if (err) reject(err);
            else resolve(rows);
          });
        });

        return {
          statusCode: 200,
          headers,
          body: JSON.stringify({ success: true, data: tenants })
        };
      }
    }

  } catch (error) {
    console.error('Tenants error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: 'Server error' })
    };
  }
};