// netlify/functions/accounting.js
const { getDatabase, authenticateToken } = require('../../src/database');

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    const authHeader = event.headers.authorization;
    const token = authHeader && authHeader.split(' ')[1];
    
    if (!token) {
      return {
        statusCode: 401,
        headers,
        body: JSON.stringify({ error: 'Access token required' })
      };
    }

    const user = await authenticateToken(token);
    if (!user) {
      return {
        statusCode: 403,
        headers,
        body: JSON.stringify({ error: 'Invalid token' })
      };
    }

    const db = await getDatabase();
    const { tenant_id, type, start_date, end_date } = event.queryStringParameters || {};
    const targetTenantId = tenant_id || user.tenantId;

    // Check access permissions
    if (user.role !== 'super_admin' && user.tenantId !== targetTenantId) {
      return {
        statusCode: 403,
        headers,
        body: JSON.stringify({ error: 'Access denied' })
      };
    }

    if (event.httpMethod === 'GET') {
      if (type === 'profit-loss') {
        // گزارش سود و زیان
        const profitLoss = await getProfitLossReport(db, targetTenantId, start_date, end_date);
        return {
          statusCode: 200,
          headers,
          body: JSON.stringify({ success: true, data: profitLoss })
        };

      } else if (type === 'commissions') {
        // گزارش کارمزدها
        const commissions = await getCommissionsReport(db, targetTenantId, start_date, end_date);
        return {
          statusCode: 200,
          headers,
          body: JSON.stringify({ success: true, data: commissions })
        };

      } else if (type === 'partners-share') {
        // تقسیم سود شرکا
        const partnersShare = await getPartnersShare(db, targetTenantId, start_date, end_date);
        return {
          statusCode: 200,
          headers,
          body: JSON.stringify({ success: true, data: partnersShare })
        };

      } else if (type === 'ledger') {
        // دفتر کل
        const ledger = await getLedger(db, targetTenantId, start_date, end_date);
        return {
          statusCode: 200,
          headers,
          body: JSON.stringify({ success: true, data: ledger })
        };

      } else if (type === 'summary') {
        // خلاصه حسابداری
        const summary = await getAccountingSummary(db, targetTenantId);
        return {
          statusCode: 200,
          headers,
          body: JSON.stringify({ success: true, data: summary })
        };
      }

    } else if (event.httpMethod === 'POST') {
      const { entry_type, amount, description, category, reference_transaction_id } = JSON.parse(event.body);
      
      // ثبت سند حسابداری
      const entryId = await createAccountingEntry(db, targetTenantId, {
        entry_type, // 'income', 'expense', 'commission'
        amount,
        description,
        category,
        reference_transaction_id,
        created_by: user.userId
      });

      return {
        statusCode: 201,
        headers,
        body: JSON.stringify({ 
          success: true, 
          message: 'Accounting entry created',
          entryId 
        })
      };
    }

    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({ error: 'Invalid request type' })
    };

  } catch (error) {
    console.error('Accounting error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: 'Server error', details: error.message })
    };
  }
};

// Helper functions
async function getProfitLossReport(db, tenantId, startDate, endDate) {
  return new Promise((resolve, reject) => {
    let query = `
      SELECT 
        entry_type,
        SUM(amount) as total,
        COUNT(*) as count,
        AVG(amount) as average
      FROM accounting_entries 
      WHERE tenant_id = ?
    `;
    let params = [tenantId];

    if (startDate && endDate) {
      query += ' AND created_at BETWEEN ? AND ?';
      params.push(startDate, endDate);
    }

    query += ' GROUP BY entry_type';

    db.all(query, params, (err, rows) => {
      if (err) reject(err);
      else {
        const report = {
          period: { start: startDate, end: endDate },
          income: 0,
          expenses: 0,
          commissions: 0,
          net_profit: 0,
          transactions_count: 0
        };

        rows.forEach(row => {
          if (row.entry_type === 'income') {
            report.income = parseFloat(row.total) || 0;
            report.transactions_count += row.count;
          }
          if (row.entry_type === 'expense') {
            report.expenses = parseFloat(row.total) || 0;
            report.transactions_count += row.count;
          }
          if (row.entry_type === 'commission') {
            report.commissions = parseFloat(row.total) || 0;
            report.transactions_count += row.count;
          }
        });

        report.net_profit = report.income + report.commissions - report.expenses;
        report.profit_margin = report.income > 0 ? (report.net_profit / report.income * 100) : 0;
        
        resolve(report);
      }
    });
  });
}

async function getCommissionsReport(db, tenantId, startDate, endDate) {
  return new Promise((resolve, reject) => {
    let query = `
      SELECT 
        t.*,
        u.name as user_name,
        u.email as user_email,
        (t.amount * COALESCE(cr.rate, 0.01)) as commission_amount,
        cr.rate as commission_rate
      FROM tenant_transactions t
      LEFT JOIN tenant_users u ON t.user_id = u.id
      LEFT JOIN commission_rates cr ON t.tenant_id = cr.tenant_id AND t.type = cr.transaction_type
      WHERE t.tenant_id = ? AND t.status = 'completed'
    `;
    let params = [tenantId];

    if (startDate && endDate) {
      query += ' AND t.created_at BETWEEN ? AND ?';
      params.push(startDate, endDate);
    }

    query += ' ORDER BY t.created_at DESC';

    db.all(query, params, (err, rows) => {
      if (err) reject(err);
      else {
        const summary = {
          total_commission: 0,
          transactions_count: rows.length,
          average_commission: 0,
          by_type: {}
        };

        rows.forEach(row => {
          const commission = parseFloat(row.commission_amount) || 0;
          summary.total_commission += commission;
          
          if (!summary.by_type[row.type]) {
            summary.by_type[row.type] = { count: 0, total: 0 };
          }
          summary.by_type[row.type].count++;
          summary.by_type[row.type].total += commission;
        });

        summary.average_commission = summary.transactions_count > 0 
          ? summary.total_commission / summary.transactions_count 
          : 0;

        resolve({ summary, details: rows });
      }
    });
  });
}

async function getPartnersShare(db, tenantId, startDate, endDate) {
  return new Promise((resolve, reject) => {
    // ابتدا سود خالص را محاسبه کنیم
    getProfitLossReport(db, tenantId, startDate, endDate).then(profitLoss => {
      // سپس شرکا را بگیریم
      db.all('SELECT * FROM partners WHERE tenant_id = ? AND status = "active"', [tenantId], (err, partners) => {
        if (err) reject(err);
        else {
          const netProfit = profitLoss.net_profit;
          const shares = partners.map(partner => ({
            ...partner,
            share_amount: (netProfit * partner.share_percentage / 100),
            profit_percentage: partner.share_percentage
          }));

          resolve({
            net_profit: netProfit,
            total_distributed: shares.reduce((sum, share) => sum + share.share_amount, 0),
            partners: shares
          });
        }
      });
    }).catch(reject);
  });
}

async function getLedger(db, tenantId, startDate, endDate) {
  return new Promise((resolve, reject) => {
    let query = `
      SELECT 
        ae.*,
        u.name as created_by_name,
        t.type as transaction_type,
        t.amount as transaction_amount
      FROM accounting_entries ae
      LEFT JOIN platform_users u ON ae.created_by = u.id
      LEFT JOIN tenant_transactions t ON ae.reference_transaction_id = t.id
      WHERE ae.tenant_id = ?
    `;
    let params = [tenantId];

    if (startDate && endDate) {
      query += ' AND ae.created_at BETWEEN ? AND ?';
      params.push(startDate, endDate);
    }

    query += ' ORDER BY ae.created_at DESC';

    db.all(query, params, (err, rows) => {
      if (err) reject(err);
      else resolve(rows);
    });
  });
}

async function getAccountingSummary(db, tenantId) {
  return new Promise(async (resolve, reject) => {
    try {
      const profitLoss = await getProfitLossReport(db, tenantId);
      const commissions = await getCommissionsReport(db, tenantId);
      
      db.get(`
        SELECT 
          COUNT(DISTINCT t.id) as total_transactions,
          SUM(t.amount) as total_volume,
          COUNT(DISTINCT u.id) as active_users
        FROM tenant_transactions t
        LEFT JOIN tenant_users u ON t.user_id = u.id
        WHERE t.tenant_id = ? AND t.status = 'completed'
      `, [tenantId], (err, stats) => {
        if (err) reject(err);
        else {
          resolve({
            financial: profitLoss,
            commissions: commissions.summary,
            operations: {
              total_transactions: stats.total_transactions || 0,
              total_volume: parseFloat(stats.total_volume) || 0,
              active_users: stats.active_users || 0
            }
          });
        }
      });
    } catch (error) {
      reject(error);
    }
  });
}

async function createAccountingEntry(db, tenantId, entry) {
  return new Promise((resolve, reject) => {
    db.run(`
      INSERT INTO accounting_entries (tenant_id, entry_type, amount, description, category, reference_transaction_id, created_by)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `, [
      tenantId, 
      entry.entry_type, 
      entry.amount, 
      entry.description, 
      entry.category, 
      entry.reference_transaction_id, 
      entry.created_by
    ], function(err) {
      if (err) reject(err);
      else resolve(this.lastID);
    });
  });
}