// netlify/functions/dashboard.js
const { getDatabase, authenticateToken } = require('../../src/database');

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  if (event.httpMethod !== 'GET') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Method not allowed' })
    };
  }

  try {
    const authHeader = event.headers.authorization;
    const token = authHeader && authHeader.split(' ')[1];
    
    if (!token) {
      return {
        statusCode: 401,
        headers,
        body: JSON.stringify({ error: 'Access token required' })
      };
    }

    const user = await authenticateToken(token);
    if (!user) {
      return {
        statusCode: 403,
        headers,
        body: JSON.stringify({ error: 'Invalid token' })
      };
    }

    const db = await getDatabase();
    const { type, tenant_id } = event.queryStringParameters || {};

    if (type === 'super-admin') {
      // Super Admin dashboard
      if (user.role !== 'super_admin') {
        return {
          statusCode: 403,
          headers,
          body: JSON.stringify({ error: 'Access denied' })
        };
      }

      const stats = await new Promise((resolve, reject) => {
        db.get(`
          SELECT 
            COUNT(DISTINCT t.id) as total_tenants,
            COUNT(DISTINCT tu.id) as total_users,
            COUNT(DISTINCT tt.id) as total_transactions,
            COALESCE(SUM(tt.amount), 0) as total_volume
          FROM tenants t
          LEFT JOIN tenant_users tu ON t.tenant_id = tu.tenant_id
          LEFT JOIN tenant_transactions tt ON t.tenant_id = tt.tenant_id
        `, (err, row) => {
          if (err) reject(err);
          else resolve(row);
        });
      });

      const pendingRequests = await new Promise((resolve, reject) => {
        db.get("SELECT COUNT(*) as count FROM tenants WHERE status = 'pending'", (err, row) => {
          if (err) reject(err);
          else resolve(row.count);
        });
      });

      const recentTenants = await new Promise((resolve, reject) => {
        db.all(`
          SELECT tenant_id, name, plan, created_at 
          FROM tenants 
          ORDER BY created_at DESC 
          LIMIT 5
        `, (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        });
      });

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          success: true,
          data: {
            stats,
            pendingRequests,
            recentTenants
          }
        })
      };

    } else if (type === 'tenant') {
      // Tenant dashboard
      const targetTenantId = tenant_id || user.tenantId;
      
      if (user.role !== 'super_admin' && user.tenantId !== targetTenantId) {
        return {
          statusCode: 403,
          headers,
          body: JSON.stringify({ error: 'Access denied' })
        };
      }

      const stats = await new Promise((resolve, reject) => {
        db.get(`
          SELECT 
            COUNT(DISTINCT tu.id) as total_users,
            COUNT(DISTINCT tt.id) as total_transactions,
            COALESCE(SUM(CASE WHEN tt.type = 'buy' THEN tt.amount ELSE 0 END), 0) as total_buys,
            COALESCE(SUM(CASE WHEN tt.type = 'sell' THEN tt.amount ELSE 0 END), 0) as total_sells,
            COALESCE(SUM(tt.amount), 0) as total_volume
          FROM tenant_users tu
          LEFT JOIN tenant_transactions tt ON tu.id = tt.user_id
          WHERE tu.tenant_id = ?
        `, [targetTenantId], (err, row) => {
          if (err) reject(err);
          else resolve(row);
        });
      });

      const recentTransactions = await new Promise((resolve, reject) => {
        db.all(`
          SELECT t.*, u.name as user_name
          FROM tenant_transactions t
          LEFT JOIN tenant_users u ON t.user_id = u.id
          WHERE t.tenant_id = ?
          ORDER BY t.created_at DESC
          LIMIT 10
        `, [targetTenantId], (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        });
      });

      const activeUsers = await new Promise((resolve, reject) => {
        db.all(`
          SELECT name, email, role, last_login
          FROM tenant_users
          WHERE tenant_id = ? AND status = 'active'
          ORDER BY last_login DESC
          LIMIT 5
        `, [targetTenantId], (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        });
      });

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({
          success: true,
          data: {
            stats,
            recentTransactions,
            activeUsers
          }
        })
      };
    }

    return {
      statusCode: 400,
      headers,
      body: JSON.stringify({ error: 'Invalid dashboard type' })
    };

  } catch (error) {
    console.error('Dashboard error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: 'Server error', details: error.message })
    };
  }
};