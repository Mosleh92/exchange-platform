// netlify/functions/transactions.js
const { getDatabase, authenticateToken } = require('../../src/database');

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    const authHeader = event.headers.authorization;
    const token = authHeader && authHeader.split(' ')[1];
    
    if (!token) {
      return {
        statusCode: 401,
        headers,
        body: JSON.stringify({ error: 'Access token required' })
      };
    }

    const user = await authenticateToken(token);
    if (!user) {
      return {
        statusCode: 403,
        headers,
        body: JSON.stringify({ error: 'Invalid token' })
      };
    }

    const db = await getDatabase();
    const { tenant_id, user_id, limit = 50, offset = 0 } = event.queryStringParameters || {};

    if (event.httpMethod === 'GET') {
      // Get transactions
      let query = `
        SELECT t.*, u.name as user_name, u.email as user_email
        FROM tenant_transactions t
        LEFT JOIN tenant_users u ON t.user_id = u.id
        WHERE 1=1
      `;
      let params = [];

      // Filter by tenant
      if (tenant_id) {
        if (user.role !== 'super_admin' && user.tenantId !== tenant_id) {
          return {
            statusCode: 403,
            headers,
            body: JSON.stringify({ error: 'Access denied' })
          };
        }
        query += ' AND t.tenant_id = ?';
        params.push(tenant_id);
      } else if (user.role !== 'super_admin') {
        query += ' AND t.tenant_id = ?';
        params.push(user.tenantId);
      }

      // Filter by user
      if (user_id) {
        query += ' AND t.user_id = ?';
        params.push(user_id);
      }

      query += ' ORDER BY t.created_at DESC LIMIT ? OFFSET ?';
      params.push(parseInt(limit), parseInt(offset));

      const transactions = await new Promise((resolve, reject) => {
        db.all(query, params, (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        });
      });

      // Get total count
      let countQuery = 'SELECT COUNT(*) as total FROM tenant_transactions WHERE 1=1';
      let countParams = [];
      
      if (tenant_id) {
        countQuery += ' AND tenant_id = ?';
        countParams.push(tenant_id);
      } else if (user.role !== 'super_admin') {
        countQuery += ' AND tenant_id = ?';
        countParams.push(user.tenantId);
      }

      const totalCount = await new Promise((resolve, reject) => {
        db.get(countQuery, countParams, (err, row) => {
          if (err) reject(err);
          else resolve(row.total);
        });
      });

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ 
          success: true, 
          data: transactions,
          pagination: {
            total: totalCount,
            limit: parseInt(limit),
            offset: parseInt(offset)
          }
        })
      };

    } else if (event.httpMethod === 'POST') {
      // Create new transaction
      const { 
        user_id, 
        type, 
        amount, 
        currency = 'USD', 
        description, 
        reference_id 
      } = JSON.parse(event.body);
      
      if (!tenant_id) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ error: 'Tenant ID required' })
        };
      }

      // Check permissions
      if (user.role !== 'super_admin' && user.tenantId !== tenant_id) {
        return {
          statusCode: 403,
          headers,
          body: JSON.stringify({ error: 'Access denied' })
        };
      }

      const transactionId = await new Promise((resolve, reject) => {
        db.run(`
          INSERT INTO tenant_transactions (tenant_id, user_id, type, amount, currency, description, reference_id)
          VALUES (?, ?, ?, ?, ?, ?, ?)
        `, [tenant_id, user_id, type, amount, currency, description, reference_id], function(err) {
          if (err) reject(err);
          else resolve(this.lastID);
        });
      });

      return {
        statusCode: 201,
        headers,
        body: JSON.stringify({ 
          success: true, 
          message: 'Transaction created successfully',
          transactionId 
        })
      };

    } else if (event.httpMethod === 'PUT') {
      // Update transaction status
      const { transaction_id } = event.queryStringParameters || {};
      const { status, completed_at } = JSON.parse(event.body);
      
      if (!transaction_id) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ error: 'Transaction ID required' })
        };
      }

      await new Promise((resolve, reject) => {
        db.run(`
          UPDATE tenant_transactions 
          SET status = ?, completed_at = ?
          WHERE id = ?
        `, [status, completed_at || (status === 'completed' ? new Date().toISOString() : null), transaction_id], (err) => {
          if (err) reject(err);
          else resolve();
        });
      });

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ success: true, message: 'Transaction updated successfully' })
      };
    }

  } catch (error) {
    console.error('Transactions error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: 'Server error', details: error.message })
    };
  }
};