// netlify/functions/users.js
const { getDatabase, authenticateToken } = require('../../src/database');
const bcrypt = require('bcrypt');

exports.handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  };

  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers, body: '' };
  }

  try {
    const authHeader = event.headers.authorization;
    const token = authHeader && authHeader.split(' ')[1];
    
    if (!token) {
      return {
        statusCode: 401,
        headers,
        body: JSON.stringify({ error: 'Access token required' })
      };
    }

    const user = await authenticateToken(token);
    if (!user) {
      return {
        statusCode: 403,
        headers,
        body: JSON.stringify({ error: 'Invalid token' })
      };
    }

    const db = await getDatabase();
    const { tenant_id } = event.queryStringParameters || {};

    if (event.httpMethod === 'GET') {
      // Get tenant users
      if (!tenant_id) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ error: 'Tenant ID required' })
        };
      }

      // Check access permissions
      if (user.role !== 'super_admin' && user.tenantId !== tenant_id) {
        return {
          statusCode: 403,
          headers,
          body: JSON.stringify({ error: 'Access denied' })
        };
      }

      const users = await new Promise((resolve, reject) => {
        db.all(`
          SELECT id, email, name, role, phone, status, p2p_enabled, 
                 kyc_status, balance, last_login, created_at
          FROM tenant_users 
          WHERE tenant_id = ? 
          ORDER BY created_at DESC
        `, [tenant_id], (err, rows) => {
          if (err) reject(err);
          else resolve(rows);
        });
      });

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ success: true, data: users })
      };

    } else if (event.httpMethod === 'POST') {
      // Create new user
      const { email, password, name, role = 'customer', phone } = JSON.parse(event.body);
      
      if (!tenant_id) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ error: 'Tenant ID required' })
        };
      }

      // Check permissions
      if (user.role !== 'super_admin' && user.tenantId !== tenant_id) {
        return {
          statusCode: 403,
          headers,
          body: JSON.stringify({ error: 'Access denied' })
        };
      }

      const hashedPassword = await bcrypt.hash(password, 10);
      
      await new Promise((resolve, reject) => {
        db.run(`
          INSERT INTO tenant_users (tenant_id, email, password_hash, name, role, phone)
          VALUES (?, ?, ?, ?, ?, ?)
        `, [tenant_id, email, hashedPassword, name, role, phone], function(err) {
          if (err) reject(err);
          else resolve(this.lastID);
        });
      });

      return {
        statusCode: 201,
        headers,
        body: JSON.stringify({ 
          success: true, 
          message: 'User created successfully',
          userId: this.lastID 
        })
      };

    } else if (event.httpMethod === 'PUT') {
      // Update user
      const { user_id } = event.queryStringParameters || {};
      const { name, role, phone, status, p2p_enabled } = JSON.parse(event.body);
      
      if (!user_id || !tenant_id) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ error: 'User ID and Tenant ID required' })
        };
      }

      await new Promise((resolve, reject) => {
        db.run(`
          UPDATE tenant_users 
          SET name = ?, role = ?, phone = ?, status = ?, p2p_enabled = ?
          WHERE id = ? AND tenant_id = ?
        `, [name, role, phone, status, p2p_enabled, user_id, tenant_id], (err) => {
          if (err) reject(err);
          else resolve();
        });
      });

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ success: true, message: 'User updated successfully' })
      };

    } else if (event.httpMethod === 'DELETE') {
      // Delete user
      const { user_id } = event.queryStringParameters || {};
      
      if (!user_id || !tenant_id) {
        return {
          statusCode: 400,
          headers,
          body: JSON.stringify({ error: 'User ID and Tenant ID required' })
        };
      }

      await new Promise((resolve, reject) => {
        db.run('DELETE FROM tenant_users WHERE id = ? AND tenant_id = ?', [user_id, tenant_id], (err) => {
          if (err) reject(err);
          else resolve();
        });
      });

      return {
        statusCode: 200,
        headers,
        body: JSON.stringify({ success: true, message: 'User deleted successfully' })
      };
    }

  } catch (error) {
    console.error('Users error:', error);
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ error: 'Server error', details: error.message })
    };
  }
};