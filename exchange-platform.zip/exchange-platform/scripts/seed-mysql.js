const mysql = require('mysql2/promise');
const bcrypt = require('bcrypt');
require('dotenv').config();

async function seedMySQLDatabase() {
    console.log('🌱 Seeding MySQL database with sample data...');

    const connection = await mysql.createConnection({
        host: process.env.DB_HOST,
        port: process.env.DB_PORT,
        user: process.env.DB_USER,
        password: process.env.DB_PASSWORD,
        database: process.env.DB_NAME
    });

    try {
        // Clear existing data
        await connection.execute('DELETE FROM exchanger_p2p');
        await connection.execute('DELETE FROM p2p_trades');
        await connection.execute('DELETE FROM tenant_transactions');
        await connection.execute('DELETE FROM tenant_users');
        await connection.execute('DELETE FROM platform_users');
        await connection.execute('DELETE FROM tenants');

        // Create Super Admin
        const superAdminPassword = await bcrypt.hash(process.env.SUPER_ADMIN_PASSWORD, 10);
        await connection.execute(`
            INSERT INTO platform_users (email, password_hash, role, name, phone)
            VALUES (?, ?, 'super_admin', 'مدیر کل سیستم', '+98 21 1234 5678')
        `, [process.env.SUPER_ADMIN_EMAIL, superAdminPassword]);

        // Create sample tenants
        const tenants = [
            {
                tenant_id: 'ARIA_001',
                name: 'صرافی آریا',
                subdomain: 'aria',
                plan: 'professional',
                status: 'active',
                admin_email: 'admin@aria.com',
                admin_phone: '+98 912 345 6789',
                exchange_address: 'تهران، خیابان ولیعصر، پلاک 123'
            },
            {
                tenant_id: 'TALAEI_002',
                name: 'صرافی طلایی',
                subdomain: 'talaei',
                plan: 'basic',
                status: 'active',
                admin_email: 'admin@talaei.com',
                admin_phone: '+98 913 456 7890',
                exchange_address: 'مشهد، خیابان امام رضا، پلاک 456'
            },
            {
                tenant_id: 'SEPEHR_003',
                name: 'صرافی سپهر',
                subdomain: 'sepehr',
                plan: 'enterprise',
                status: 'active',
                admin_email: 'admin@sepehr.com',
                admin_phone: '+98 914 567 8901',
                exchange_address: 'اصفهان، چهارباغ عباسی، پلاک 789'
            }
        ];

        for (const tenant of tenants) {
            await connection.execute(`
                INSERT INTO tenants (tenant_id, name, subdomain, plan, status, admin_email, admin_phone, exchange_address, approved_at, expires_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), DATE_ADD(NOW(), INTERVAL 1 YEAR))
            `, [tenant.tenant_id, tenant.name, tenant.subdomain, tenant.plan, tenant.status, tenant.admin_email, tenant.admin_phone, tenant.exchange_address]);

            // Create tenant admin
            const adminPassword = await bcrypt.hash('Admin@123', 10);
            await connection.execute(`
                INSERT INTO platform_users (email, password_hash, role, tenant_id, name, phone)
                VALUES (?, ?, 'tenant_admin', ?, ?, ?)
            `, [tenant.admin_email, adminPassword, tenant.tenant_id, `مدیر ${tenant.name}`, tenant.admin_phone]);

            // Create sample users for each tenant
            const users = [
                { name: 'علی احمدی', email: `ali@${tenant.subdomain}.com`, role: 'staff' },
                { name: 'مریم رضایی', email: `maryam@${tenant.subdomain}.com`, role: 'staff' },
                { name: 'حسن محمدی', email: `hassan@${tenant.subdomain}.com`, role: 'customer' },
                { name: 'فاطمه کریمی', email: `fateme@${tenant.subdomain}.com`, role: 'customer', p2p: true }
            ];

            for (const user of users) {
                const userPassword = await bcrypt.hash('User@123', 10);
                const [result] = await connection.execute(`
                    INSERT INTO tenant_users (tenant_id, email, password_hash, name, role, p2p_enabled, balance, kyc_status)
                    VALUES (?, ?, ?, ?, ?, ?, ?, 'approved')
                `, [tenant.tenant_id, user.email, userPassword, user.name, user.role, user.p2p || false, Math.random() * 10000]);

                // Create sample transactions
                for (let i = 0; i < 5; i++) {
                    await connection.execute(`
                        INSERT INTO tenant_transactions (tenant_id, user_id, type, amount, currency, status, description)
                        VALUES (?, ?, ?, ?, 'USD', 'completed', ?)
                    `, [
                        tenant.tenant_id,
                        result.insertId,
                        Math.random() > 0.5 ? 'buy' : 'sell',
                        Math.floor(Math.random() * 1000) + 100,
                        `Sample transaction ${i + 1}`
                    ]);
                }
            }
        }

        console.log('✅ MySQL database seeded successfully!');
        console.log('📊 Sample data created for InfinityFree:');
        console.log('   👑 1 Super Admin');
        console.log('   🏢 3 Tenants (Exchanges)');
        console.log('   👥 3 Tenant Admins');
        console.log('   👤 12 Tenant Users');
        console.log('   💰 60 Transactions');

        console.log('\n🔐 Login credentials:');
        console.log(`   Super Admin: ${process.env.SUPER_ADMIN_EMAIL} / ${process.env.SUPER_ADMIN_PASSWORD}`);
        console.log('   Tenant Admins: admin@[subdomain].com / Admin@123');
        console.log('   Users: [name]@[subdomain].com / User@123');

    } catch (error) {
        console.error('❌ MySQL seeding failed:', error);
        throw error;
    } finally {
        await connection.end();
    }
}

seedMySQLDatabase().catch(console.error);